
public class LoopAnalyze {

	public final int ITERACIONS = 100000000;	
	public String concatText = "This is a String for testing";

	public int index = 0;
	
	public static void main(String[] args) {

		LoopAnalyze main = new LoopAnalyze ();
		
		main.testFor();
		main.testWhile ();
		main.testDoWhile ();
		
		main.testSimulacioFor ();

	}

	public void testFor() {
		
		long iniTime = System.currentTimeMillis();
		for (int cont1=0; cont1<ITERACIONS; cont1++) {
			String test = "This is a String for testing";
		}
		long endTime = System.currentTimeMillis();
		System.out.println ("Temps de concatenaci� amb la sent�ncia \"for\": "+(endTime-iniTime)+" mseg");
	}
	
	public void testWhile () {
		
		long iniTime = System.currentTimeMillis();
		
		int cont1 = 0;
		while (cont1<ITERACIONS) {
			String test = "This is a String for testing";
			cont1++;
		}

		long endTime = System.currentTimeMillis();
		System.out.println ("Temps de concatenaci� amb la sent�ncia \"while\": "+(endTime-iniTime)+" mseg");		
	}
	
	public void testDoWhile () {
		
		long iniTime = System.currentTimeMillis();
		
		int cont1 = 0;
		do  {
			String test = "This is a String for testing";
			cont1++;
		}
		while (cont1<ITERACIONS);

		long endTime = System.currentTimeMillis();
		System.out.println ("Temps de concatenaci� amb la sent�ncia \"doWhile\": "+(endTime-iniTime)+" mseg");
		
	}
	
	private void inicialitzacio() {
		index = 0;
	}
	
	private void increment() {
		index++;
	}
	
	public void testSimulacioFor () {
		
		long iniTime = System.currentTimeMillis();
		
		inicialitzacio();
		while (index<ITERACIONS) {
			String test = "This is a String for testing";
			increment();
		}

		long endTime = System.currentTimeMillis();
		System.out.println ("Temps de concatenaci� simulant un bucle \"for\": "+(endTime-iniTime)+" mseg");		
	}
	
}
