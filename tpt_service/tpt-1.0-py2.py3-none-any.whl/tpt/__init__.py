"""
TPT init module
"""
from tpt.commons import TPTException
from tpt.tpt import TPT


__all__ = [
    'TPT',
    'TPTException'
]
