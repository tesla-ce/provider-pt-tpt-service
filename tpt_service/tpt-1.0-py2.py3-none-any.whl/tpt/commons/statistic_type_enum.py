"""
Statistic type
"""
import enum


class StatisticTypeEnum(enum.Enum):
    """
    Statistic type class
    """
    ELAPSED_TIME = "elapsed_time"
