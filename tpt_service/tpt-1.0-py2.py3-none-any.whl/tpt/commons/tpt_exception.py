"""
TPT Exception
"""


class TPTException(Exception):
    """
    TPT Exception base class
    """
