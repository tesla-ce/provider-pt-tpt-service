"""
Comparator module
"""
from .tpt_comparator import TPTComparator

__all__ = [
    'TPTComparator'
]
