"""
Event init module
"""
from .event import Event
from .event import EventHandler

__all__ = [
    'Event',
    'EventHandler'
]
