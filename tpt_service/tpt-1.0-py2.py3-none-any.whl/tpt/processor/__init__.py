"""
TPT Processor module
"""
from .tpt_processor import TPTProcessor

__all__ = [
    'TPTProcessor'
]
